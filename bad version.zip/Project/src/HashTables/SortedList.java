package HashTables;

import stack_queue.LinkedStack;

import java.io.Serializable;

public class SortedList<E> implements Serializable {
    private Node<E> head = null;

    public void addWebsite(String date, String url, String title, String Time) {
        Website web = new Website(url, date, title, Time);
        int keyValue = Math.abs(date.hashCode());
        Node<E> previous = null;
        Node<E> current = head;
        ;
        while (current != null && keyValue > current.key) {
            previous = current;
            current = current.next;
        }
        if (previous == null) {
            head = new Node(keyValue, web, head);
            System.out.println("Website added");
        } else
            previous.next = new Node(keyValue, web, current);
    }

    public int displayAllWebsites(String date) {
        int keydate = Math.abs(date.hashCode());
        Node<E> current = head;
        int count = 0;
        LinkedStack<Website> e = new LinkedStack<>();
        while (current != null && current.key <= keydate) {
            if (current.key == keydate) {
                while (current.s.isEmpty() != true) {
                    if (current.s.top() != null)
                        System.out.println(current.s.top().toString());
                    e.push(current.s.pop());
                    count += 1;
                }
            }
            while (e.isEmpty() != true) {
                current.s.push(e.pop());
            }
            current = current.next;
        }
        return count;
    }
    public int SearchWebsite(String url) {
        Node<E> current = head;
        LinkedStack<Website> tmp = new LinkedStack<>();
        int c = 0;
        while (current != null) {
            LinkedStack<Website> web = current.s;
            if (web.top() != null)
                if (web.top().getUrl().equalsIgnoreCase(url)) {
                    c += 1;
                    System.out.println("Date:  " + web.top().getDate() + "  ,Time: " + web.top().getTime());
                } else {
                    tmp.push(web.pop());
                }
            if (web.top() == null) {
                while (tmp.isEmpty() != true)
                    web.push(tmp.pop());
            }
            current = current.next;
        }
        return c;
    }
    public int deleteWebsite(String date, String url) {
        int keydate = Math.abs(date.hashCode());
        Node<E> current = head;
        int c = 0;
        LinkedStack<Website> e = new LinkedStack<>();
        while (current != null) {
            if (current.key == keydate) {
                while (!current.s.isEmpty()) {
                    if (current.s.top() != null)
                        if (current.s.top().getUrl().hashCode() == url.hashCode()) {
                            current.s.pop();
                            c += 1;
                            System.out.println("Website deleted");
                        }
                    e.push(current.s.pop());
                }
                while (!e.isEmpty()) {
                    current.s.push(e.pop());
                }
            }
            current = current.next;
        }
        return c;
    }
}