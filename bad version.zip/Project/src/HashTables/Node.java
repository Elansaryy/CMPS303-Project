package HashTables;

import stack_queue.LinkedStack;

import java.io.Serializable;

public class Node<E> implements Serializable {
    int key;
    LinkedStack<Website> s = new LinkedStack<>();
    Node next;

    public Node(int k, Website d, Node<E> n) {
        key = k;
        s.push(d);
        next = n;
    }
}