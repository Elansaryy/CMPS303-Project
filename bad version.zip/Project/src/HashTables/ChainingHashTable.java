package HashTables;

import java.io.Serializable;

public class ChainingHashTable<E> implements Serializable {
    private SortedList[] hashArray;

    public ChainingHashTable(int size) {
        hashArray = new SortedList[size];
        for (int j = 0; j < hashArray.length; j++)
            hashArray[j] = new SortedList();
    }

    public int hashFunc(int key) {
        return key % hashArray.length;
    }

    public void addWebsite(String date, String url, String title, String Time) {
        int hashVal = hashFunc(Math.abs(date.hashCode()));
        hashArray[hashVal].addWebsite(date, url, title, Time);
    }

    public void deleteWebsite(String date, String url) {
        int x;
        int hashVal = hashFunc(Math.abs(date.hashCode()));
        try {
            x = hashArray[hashVal].deleteWebsite(date, url);
            if (x == 0) {
                System.out.println("the Website with url: " + url + ", Never been visited in Date: " + date);
            }
        } catch (Exception e) {
            System.out.println("Website with url:" + url + ", Never been visited in this date");
        }
    }

    public void SearchWebsite(String url) {
        int x = 0;
        for (int i = 0; i < hashArray.length; i++) {
            x += hashArray[i].SearchWebsite(url);
        }
        if (x == 0)
            System.out.println("this Website Never been visited");
    }

    public void displayAllWebsites(String date) {
        int hashVal = hashFunc(Math.abs(date.hashCode()));
        try {
            int x = hashArray[hashVal].displayAllWebsites(date);
            if (x == 0)
                System.out.println("No websites in this date");
        } catch (Exception e) {
            System.out.println("No Websites visited in this date");
        }

    }
}
